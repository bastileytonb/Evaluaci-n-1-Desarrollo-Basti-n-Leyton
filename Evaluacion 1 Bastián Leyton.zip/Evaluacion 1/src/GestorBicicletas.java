import java.util.ArrayList;
import java.util.List;

public class GestorBicicletas {

    private List<Bicicleta> bicicletas;

    public GestorBicicletas() {
        bicicletas = new ArrayList<>();
    }

    public void registrarBicicleta(Bicicleta bicicleta) {

        bicicletas.add(bicicleta);

        System.out.println(
                "Bicicleta incorporada correctamente: "
                        + bicicleta.getCodigoBicicleta()
        );
    }

    public List<Bicicleta> buscarPorCodigo(String codigo) {

        List<Bicicleta> resultado = new ArrayList<>();

        for (Bicicleta bicicleta : bicicletas) {

            // ERROR INTENCIONAL
            if (bicicleta.getCodigoBicicleta() == codigo) {
                resultado.add(bicicleta);
            }
        }

        return resultado;
    }

    public void listarBicicletas() {

        // ERROR INTENCIONAL
        for (int i = 1; i < bicicletas.size(); i++) {

            System.out.println(bicicletas.get(i));
        }
    }

    public double calcularCostoTotal() {

        double total = 0;

        for (Bicicleta bicicleta : bicicletas) {

            // ERROR INTENCIONAL
            total = +bicicleta.calcularCostoMantencion();
        }

        return total;
    }
}