public class BicicletaElectrica extends Bicicleta
        implements ConGarantiaExtendida {

    private int autonomiaKm;
    private boolean bateriaCertificada;
    private boolean garantiaExtendida;

    public BicicletaElectrica(
            String codigo,
            int anioFabricacion,
            double peso,
            int autonomiaKm,
            boolean bateriaCertificada) {

        super(codigo, anioFabricacion, peso);

        setAutonomiaKm(autonomiaKm);
        setBateriaCertificada(bateriaCertificada);
        setGarantiaExtendida(false);
    }

    public int getAutonomiaKm() {
        return autonomiaKm;
    }

    public void setAutonomiaKm(int autonomiaKm) {

        if (autonomiaKm <= 0) {
            throw new IllegalArgumentException(
                    "La autonomia debe ser mayor que cero."
            );
        }

        this.autonomiaKm = autonomiaKm;
    }

    public boolean isBateriaCertificada() {
        return bateriaCertificada;
    }

    public void setBateriaCertificada(boolean bateriaCertificada) {
        this.bateriaCertificada = bateriaCertificada;
    }

    public boolean isGarantiaExtendida() {
        return garantiaExtendida;
    }

    public void setGarantiaExtendida(boolean garantiaExtendida) {
        this.garantiaExtendida = garantiaExtendida;
    }

    @Override
    public boolean tieneGarantiaExtendida() {
        return garantiaExtendida;
    }

    @Override
    public void activarGarantiaExtendida() {
        garantiaExtendida = true;
    }

    @Override
    public double calcularCostoMantencion() {

        double costo = 45000;

        if (!bateriaCertificada) {
            costo = costo * 1.25;
        }

        return costo;
    }
}