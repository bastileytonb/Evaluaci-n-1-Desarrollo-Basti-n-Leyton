import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        GestorBicicletas gestor = new GestorBicicletas();

        BicicletaElectrica electrica1 =
                new BicicletaElectrica(
                        "BIC-E01",
                        2023,
                        22.5,
                        60,
                        false
                );

        BicicletaElectrica electrica2 =
                new BicicletaElectrica(
                        "BIC-E02",
                        2022,
                        24.0,
                        45,
                        true
                );

        BicicletaMontana montana1 =
                new BicicletaMontana(
                        "BIC-M01",
                        2021,
                        13.5,
                        2
                );

        BicicletaMontana montana2 =
                new BicicletaMontana(
                        "BIC-M02",
                        2020,
                        12.0,
                        1
                );

        electrica1.activarGarantiaExtendida();

        gestor.registrarBicicleta(electrica1);
        gestor.registrarBicicleta(electrica2);
        gestor.registrarBicicleta(montana1);
        gestor.registrarBicicleta(montana2);

        System.out.println("\n===== BICICLETAS REGISTRADAS =====");

        gestor.listarBicicletas();

        System.out.println("\n===== BÚSQUEDA POR CÓDIGO =====");

        System.out.print("Ingrese código: ");
        String codigo = scanner.nextLine();

        List<Bicicleta> resultado =
                gestor.buscarPorCodigo(codigo);

        if (resultado.isEmpty()) {

            System.out.println("No se encontraron bicicletas.");

        } else {

            for (Bicicleta bicicleta : resultado) {
                System.out.println(bicicleta);
            }
        }

        System.out.println("\n===== COSTOS DE MANTENCIÓN =====");

        for (Bicicleta bicicleta : resultado) {

            System.out.println(
                    bicicleta.getCodigoBicicleta()
                            + ": $"
                            + bicicleta.calcularCostoMantencion()
            );
        }

        System.out.println("\n===== COSTO TOTAL =====");

        System.out.println(
                "Costo total: $" + gestor.calcularCostoTotal()
        );

        scanner.close();
    }
}